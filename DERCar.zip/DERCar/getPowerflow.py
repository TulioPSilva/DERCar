import sys
import py_dss_interface
import pandas as pd
#import matplotlib.pyplot as plt

circuit_pu = 1.04
load_mult = 0.3
usina_kw = 0

def process(condominio_penetration_kw, condominio_injection_kw, posto1_penetration_kw, posto1_injection_kw, posto2_penetration_kw, posto2_injection_kw, power_gen_diesel):
    condominio_penetration_kw = condominio_penetration_kw.replace(',','.')
    condominio_injection_kw = condominio_injection_kw.replace(',','.')
    posto1_penetration_kw = posto1_penetration_kw.replace(',','.')
    posto1_injection_kw = posto1_injection_kw.replace(',','.')
    posto2_penetration_kw = posto2_penetration_kw.replace(',','.')
    posto2_injection_kw = posto2_injection_kw.replace(',','.')
    power_gen_diesel = power_gen_diesel.replace(',','.')

    dss.text(f"Compile [{dss_file}]")

    dss.text("New Energymeter.m1 Line.LN5815900-1")

    # Thevenin Equivalent
    dss.text(f"edit vsource.source pu={circuit_pu}")
    dss.text("edit Reactor.HVMV_Sub_HSB x=0.0000001")  # Desconsiderando reator
    dss.text("edit Transformer.HVMV_Sub %loadloss=0.0000001 xhl=00000001")  # Desconsiderando capacitor

    # Control elements
    dss.text("set controlmode=Off")
    dss.text("batchedit capacitor..* enabled=no")

    # Load models
    dss.text("batchedit load..* mode=1")
    dss.text("batchedit load..* vmaxpu=1.25")
    dss.text("batchedit load..* vminpu=0.75")

    # Load condition
    dss.text(f"set loadmult={load_mult}")

    dss.text("Set Maxiterations=100")
    dss.text("set maxcontrolit=100")

    dss.text("AddBusMarker bus=n1142103 color=red size=8 code=15")

    # 1. Variar a penetração de GD
    dss.text(f"New generator.condominio phases=3 bus1=n1142103 kV=12.470 pf=1 kW={condominio_penetration_kw}")
    dss.text(f"New generator.posto1 phases=3 bus1=l3104136 kV=12.470 pf=1 kW={posto1_penetration_kw}")
    dss.text(f"New generator.posto2 phases=3 bus1=l3216123 kV=12.470 pf=1 kW={posto2_penetration_kw}")
    dss.text(f"New generator.gen_diesel phases=3 bus1=n1142103 kV=12.470 pf=1 kW={power_gen_diesel}")

    # 1. Incluir carga
    dss.text(f"New Load.carcondominio phases=3 bus1=n1142103  kv=12.470 model=1 conn=wye kW={condominio_injection_kw} pf=0.97")
    dss.text(f"New Load.carposto1 phases=3 bus1=l3104136  kv=12.470 model=1 conn=wye kW={posto1_injection_kw} pf=0.97")
    dss.text(f"New Load.carposto2 phases=3 bus1=l3216123  kv=12.470 model=1 conn=wye kW={posto2_injection_kw} pf=0.97")
    dss.solution_solve()

    total_p_feederhead = -1 * dss.circuit_total_power()[0]
    total_q_feederhead = -1 * dss.circuit_total_power()[1]
    losses_kw = dss.circuit_losses()[0] / 10 ** 3
    losses_kvar = dss.circuit_losses()[1] / 10 ** 3
    voltages = dss.circuit_all_bus_vmag_pu()
    voltage_max = max(voltages)
    voltage_min = min(voltages)

    return total_p_feederhead, total_q_feederhead, losses_kw, losses_kvar, voltage_max, voltage_min

dss_file = r"C:\Action.NET\ProjectsPython\DERCar\8500-Node\Master.dss"
dss = py_dss_interface.DSSDLL()

condominio_penetration_kw = sys.argv[1]
condominio_injection_kw = sys.argv[2]
posto1_penetration_kw = sys.argv[3]
posto1_injection_kw = sys.argv[4]
posto2_penetration_kw = sys.argv[5]
posto2_injection_kw = sys.argv[6]
power_gen_diesel = sys.argv[7]
results = process(condominio_penetration_kw,condominio_injection_kw,posto1_penetration_kw,posto1_injection_kw,posto2_penetration_kw,posto2_injection_kw,power_gen_diesel)
print(results)