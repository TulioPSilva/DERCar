﻿import sys
import py_dss_interface

#Método para obtér as linhas conectadas o barramento definido para conectar o impleendimento
def getlinesconnect(bus_condominio):
    dss_file = r"C:\Action.NET\ProjectsPython\DERCar\8500-Node\Master.dss"
    dss = py_dss_interface.DSSDLL()

    dss.text(f"Compile [{dss_file}]")
    dss.solution_solve()

    dss.circuit_set_active_bus(bus_condominio)
    linhas = dss.bus_line_list()
    return linhas

# Método para obtér as barras conectadas as linhas
def getLineBus(linha):
    dss_file = r"C:\Action.NET\ProjectsPython\DERCar\8500-Node\Master.dss"
    dss = py_dss_interface.DSSDLL()

    dss.text(f"Compile [{dss_file}]")
    dss.solution_solve()

    dss.circuit_set_active_element(linha)
    bus1 = dss.lines_read_bus1()
    bus2 = dss.lines_read_bus2()
    return bus1, bus2

bus_condominio = sys.argv[1]
#bus_condominio = 'n1142103'

linhas = getlinesconnect(bus_condominio)

new_lines = ['','']

for j in linhas:
    buses = getLineBus(j)
    if bus_condominio == buses[0]:
        new_lines[1] = j
    else:
        new_lines[0] = j

if new_lines[0] == '' or new_lines[1] == '':
    print('Defina outra barra')
else:
    print(new_lines)