import sys
import py_dss_interface
import pandas as pd
#import matplotlib.pyplot as plt

circuit_pu = 1.04
load_mult = 0.3
usina_kw = 0

def process(condominio_penetration_kw, condominio_injection_kw, posto1_penetration_kw, posto1_injection_kw, posto2_penetration_kw, posto2_injection_kw, power_gen_diesel):
    # Força os dados do SCADA para float
    condominio_penetration_kw = condominio_penetration_kw.replace(',','.')
    condominio_injection_kw = condominio_injection_kw.replace(',','.')
    posto1_penetration_kw = posto1_penetration_kw.replace(',','.')
    posto1_injection_kw = posto1_injection_kw.replace(',','.')
    posto2_penetration_kw = posto2_penetration_kw.replace(',','.')
    posto2_injection_kw = posto2_injection_kw.replace(',','.')
    power_gen_diesel = power_gen_diesel.replace(',','.')

    dss.text(f"Compile [{dss_file}]")

    dss.text("New Energymeter.m1 Line.LN5815900-1")  #Inclui o medidor

    # Equivalente Thevenin
    dss.text(f"edit vsource.source pu={circuit_pu}")
    dss.text("edit Reactor.HVMV_Sub_HSB x=0.0000001")  # Desconsiderando reator
    dss.text("edit Transformer.HVMV_Sub %loadloss=0.0000001 xhl=00000001")  # Desconsiderando capacitor

    # Desabilitar os elementos de controle
    dss.text("set controlmode=Off")
    dss.text("batchedit capacitor..* enabled=no")

    # Definindo paramêtros comuns para todas as cargas
    dss.text("batchedit load..* mode=1")
    dss.text("batchedit load..* vmaxpu=1.25")
    dss.text("batchedit load..* vminpu=0.75")

    # Definindo a condição da carga
    dss.text(f"set loadmult={load_mult}")

    # Definindo criterios maximos para a simulação
    dss.text("Set Maxiterations=100")
    dss.text("set maxcontrolit=100")

    #dss.text("AddBusMarker bus=n1142103 color=red size=8 code=15")  #Add marcador

    # 1. Variar a penetração de GD
    dss.text(f"New generator.condominio phases=3 bus1=n1142103 kV=12.470 pf=1 kW={condominio_penetration_kw}")
    dss.text(f"New generator.posto1 phases=3 bus1=l3104136 kV=12.470 pf=1 kW={posto1_penetration_kw}")
    dss.text(f"New generator.posto2 phases=3 bus1=l3216123 kV=12.470 pf=1 kW={posto2_penetration_kw}")
    dss.text(f"New generator.gen_diesel phases=3 bus1=n1142103 kV=12.470 pf=1 kW={power_gen_diesel}")

    # 1. Incluir carga
    dss.text(f"New Load.carcondominio phases=3 bus1=n1142103  kv=12.470 model=1 conn=wye kW={condominio_injection_kw} pf=0.97")
    dss.text(f"New Load.carposto1 phases=3 bus1=l3104136  kv=12.470 model=1 conn=wye kW={posto1_injection_kw} pf=0.97")
    dss.text(f"New Load.carposto2 phases=3 bus1=l3216123  kv=12.470 model=1 conn=wye kW={posto2_injection_kw} pf=0.97")
    dss.solution_solve()

    # Elemento linha conectado a barra n1142103

    dss.circuit_set_active_element("Line.LN6321372-3")
    pot_ativa_condominio_fonte = dss.cktelement_powers()[0] + dss.cktelement_powers()[2] + dss.cktelement_powers()[4]
    pot_reativa_condominio_fonte = dss.cktelement_powers()[1] + dss.cktelement_powers()[3] + dss.cktelement_powers()[5]

    dss.circuit_set_active_element("Line.LN6321372-2")
    pot_ativa_condominio_carga = dss.cktelement_powers()[0] + dss.cktelement_powers()[2] + dss.cktelement_powers()[4]
    pot_reativa_condominio_carga = dss.cktelement_powers()[1] + dss.cktelement_powers()[3] + dss.cktelement_powers()[5]

    # Elemento linha conectado a barra l3104136

    dss.circuit_set_active_element("Line.LN6298585-2")
    pot_ativa_posto1_fonte = dss.cktelement_powers()[0] + dss.cktelement_powers()[2] + dss.cktelement_powers()[4]
    pot_reativa_posto1_fonte = dss.cktelement_powers()[1] + dss.cktelement_powers()[3] + dss.cktelement_powers()[5]

    dss.circuit_set_active_element("Line.LN5867683-2")
    pot_ativa_posto1_carga = dss.cktelement_powers()[0] + dss.cktelement_powers()[2] + dss.cktelement_powers()[4]
    pot_reativa_posto1_carga = dss.cktelement_powers()[1] + dss.cktelement_powers()[3] + dss.cktelement_powers()[5]

    # Elemento linha conectado a barra l3216123

    dss.circuit_set_active_element("Line.LN6134514-1")
    pot_ativa_posto2_fonte = dss.cktelement_powers()[0] + dss.cktelement_powers()[2] + dss.cktelement_powers()[4]
    pot_reativa_posto2_fonte = dss.cktelement_powers()[1] + dss.cktelement_powers()[3] + dss.cktelement_powers()[5]

    dss.circuit_set_active_element("Line.LN5895793-1")
    pot_ativa_posto2_carga = dss.cktelement_powers()[0] + dss.cktelement_powers()[2] + dss.cktelement_powers()[4]
    pot_reativa_posto2_carga = dss.cktelement_powers()[1] + dss.cktelement_powers()[3] + dss.cktelement_powers()[5]

    # Elemento linha conectado a barra da subestação
    dss.circuit_set_active_element("Line.LN5815900-1")
    pot_ativa_fonte = dss.cktelement_powers()[0] + dss.cktelement_powers()[2] + dss.cktelement_powers()[4]
    pot_reativa_fonte = dss.cktelement_powers()[1] + dss.cktelement_powers()[3] + dss.cktelement_powers()[5]

    # Elemento gerador diesel
    dss.circuit_set_active_element("Generator.GEN_DIESEL")
    pot_ativa_gen_diesel = dss.cktelement_powers()[0] + dss.cktelement_powers()[2] + dss.cktelement_powers()[4]
    pot_reativa_gen_diesel = dss.cktelement_powers()[1] + dss.cktelement_powers()[3] + dss.cktelement_powers()[5]

    return pot_ativa_condominio_fonte, pot_reativa_condominio_fonte, pot_ativa_condominio_carga, pot_reativa_condominio_carga, pot_ativa_posto1_fonte, pot_reativa_posto1_fonte, pot_ativa_posto1_carga, pot_reativa_posto1_carga, pot_ativa_posto2_fonte, pot_reativa_posto2_fonte, pot_ativa_posto2_carga, pot_reativa_posto2_carga, pot_ativa_fonte, pot_reativa_fonte, pot_ativa_gen_diesel, pot_reativa_gen_diesel

dss_file = r"C:\Action.NET\ProjectsPython\DERCar\8500-Node\Master.dss"
dss = py_dss_interface.DSSDLL()

# Recebe os dados do SCADA
condominio_penetration_kw = sys.argv[1]
condominio_injection_kw = sys.argv[2]
posto1_penetration_kw = sys.argv[3]
posto1_injection_kw = sys.argv[4]
posto2_penetration_kw = sys.argv[5]
posto2_injection_kw = sys.argv[6]
power_gen_diesel = sys.argv[7]

# Parametros de teste
# condominio_injection_kw = '0.00000001'
# posto1_injection_kw = '26.4'
# posto2_injection_kw = '52.8'
# condominio_penetration_kw = '01584'
# posto1_penetration_kw = '0.00000001'
# posto2_penetration_kw = '0.00000001'
# power_gen_diesel = '0.00000001'

#Resultados enviados para o SCADA
results = process(condominio_penetration_kw,condominio_injection_kw,posto1_penetration_kw,posto1_injection_kw,posto2_penetration_kw,posto2_injection_kw,power_gen_diesel)
print(results)