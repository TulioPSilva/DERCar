import sys
import py_dss_interface

#Método para obtér as linhas conectadas o barramento definido para conectar o impleendimento
def getlinesconnect(bus_condominio):
    dss_file = r"C:\Action.NET\ProjectsPython\DERCar\8500-Node\Master.dss"
    dss = py_dss_interface.DSSDLL()

    dss.text(f"Compile [{dss_file}]")
    dss.solution_solve()

    dss.circuit_set_active_bus(bus_condominio)
    linhas = dss.bus_line_list()
    return linhas

# Método para obtér a corrente maxima no condutor (Limite de sobrecarga)
def getLimitSobrecarga(linha):
    dss_file = r"C:\Action.NET\ProjectsPython\DERCar\8500-Node\Master.dss"
    dss = py_dss_interface.DSSDLL()

    dss.text(f"Compile [{dss_file}]")
    dss.solution_solve()

    dss.circuit_set_active_element(linha)
    norm_amps = dss.lines_read_norm_amps()
    return norm_amps

# Método para obtér as barras conectadas as linhas
def getLineBus(linha):
    dss_file = r"C:\Action.NET\ProjectsPython\DERCar\8500-Node\Master.dss"
    dss = py_dss_interface.DSSDLL()

    dss.text(f"Compile [{dss_file}]")
    dss.solution_solve()

    dss.circuit_set_active_element(linha)
    bus1 = dss.lines_read_bus1()
    bus2 = dss.lines_read_bus2()
    return bus1, bus2

def getOpenDSS(circuit_pu,load_mult,bus_condominio,consumo_carros,linha,limit_sobrecarga):

    #Preparando dados
    circuit_pu = str(circuit_pu).replace(',','.')
    load_mult = str(load_mult).replace(',', '.')
    consumo_carros = str(consumo_carros).replace(',', '.')

    dss_file = r"C:\Action.NET\ProjectsPython\DERCar\8500-Node\Master.dss"
    dss = py_dss_interface.DSSDLL()

    dss.text(f"Compile [{dss_file}]")

    dss.text("New Energymeter.m1 Line.LN5815900-1")  # Inclui o medidor

    # Equivalente Thevenin
    dss.text(f"edit vsource.source pu={circuit_pu}")
    dss.text("edit Reactor.MDV_SUB_1_HSB x=0.0000001")  # Desconsiderando reator
    dss.text("edit Transformer.MDV_SUB_1 %loadloss=0.0000001 xhl=0.0000001")  # Desconsiderando capacitor

    # Desabilitar os elementos de controle
    dss.text("set controlmode=Off")
    dss.text("batchedit capacitor..* enabled=no")

    # Definindo paramêtros comuns para todas as cargas
    dss.text("batchedit load..* mode=1")
    dss.text("batchedit load..* vmaxpu=1.25")
    dss.text("batchedit load..* vminpu=0.75")

    # Definindo a condição da carga
    dss.text(f"set loadmult={load_mult}")

    # Definindo criterios maximos para a simulação
    dss.text("Set Maxiterations=100")
    dss.text("set maxcontrolit=100")

    dss.text(f"AddBusMarker bus={bus_condominio} color=red size=8 code=15")  # Add marcador

    # 1. Variar a penetração de GD
    if(float(consumo_carros) > 0):
        dss.text(f"New generator.condominio phases=3 bus1={bus_condominio} kV=12.47 pf=1 kw={consumo_carros}")
    else:
        consumo_carros = consumo_carros.replace('-', '')
        dss.text(f"New Load.condominio phases=2 bus1={bus_condominio} kV=12.470 pf=1 kW={consumo_carros}")

    dss.solution_solve()

    #Perdas
    perdas_ativas = dss.circuit_losses()[0] / 10 ** 3
    perdas_reativas = dss.circuit_losses()[1] / 10 ** 3

    #Tensão
    voltages = dss.circuit_all_bus_vmag_pu()
    voltage_max = max(voltages)
    voltage_min = min(voltages)

    dss.circuit_set_active_element(linha)
    pot_ativa = dss.cktelement_powers()[0] + dss.cktelement_powers()[2] + dss.cktelement_powers()[4]
    pot_reativa = dss.cktelement_powers()[1] + dss.cktelement_powers()[3] + dss.cktelement_powers()[5]
    corrente_faseA = dss.cktelement_currents_mag_ang()[0]
    corrente_faseB = dss.cktelement_currents_mag_ang()[2]
    corrente_faseC = dss.cktelement_currents_mag_ang()[4]

    sobrecarga = 0
    #Verificar sobrecarga
    if corrente_faseA >= limit_sobrecarga:
        sobrecarga = 1

    if corrente_faseB >= limit_sobrecarga:
        sobrecarga = 1

    if corrente_faseB >= limit_sobrecarga:
        sobrecarga = 1

    sobretensao = 0
    if float(circuit_pu) < float(voltage_max):
        sobretensao = 1

    return pot_ativa, pot_reativa, corrente_faseA, corrente_faseB, corrente_faseC,sobrecarga, linha, perdas_ativas, perdas_reativas, voltage_max, voltage_min, sobretensao

# Dados inseridos
circuit_pu = sys.argv[1]
load_mult = sys.argv[2]
bus_condominio = sys.argv[4]   #'n1142103'
potencia_total = sys.argv[3]

# print(circuit_pu, load_mult, bus_condominio, potencia_total)

#'n1142103'

# circuit_pu = 1.04
# load_mult = 0.3
# bus_condominio = 'n1142103'
# potencia_total = -1000

linhas = getlinesconnect(bus_condominio)

new_lines = ['','']

for j in linhas:
    buses = getLineBus(j)
    if bus_condominio == buses[0]:
        new_lines[1] = j
    else:
        new_lines[0] = j

result_end = []

for i in new_lines:
    linha = i
    limit_sobrecarga = getLimitSobrecarga(i)
    results = getOpenDSS(circuit_pu, load_mult, bus_condominio, potencia_total, linha, limit_sobrecarga)
    result_end.append(results)

print(result_end)

